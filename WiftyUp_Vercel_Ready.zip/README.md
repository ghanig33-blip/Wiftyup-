# WiftyUp
Connect • Create • Earn
## Vercel
Required environment variables:
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
Never use a Supabase secret/service-role key in the frontend.